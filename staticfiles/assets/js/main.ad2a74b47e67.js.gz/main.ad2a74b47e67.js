const carsDataBox = document.getElementById('countryddl')
const carInput = document.getElementById('city')